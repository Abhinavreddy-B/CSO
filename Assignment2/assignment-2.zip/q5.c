#include <stdio.h>
int main() {
    int i ;
    printf("Learning about binaries\n");
	return 0;
}

